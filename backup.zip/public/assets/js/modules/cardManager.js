import * as cardRenderer from "./cardRenderer.js";
let items = [],
  eventHandlers = {},
  subscribers = [],
  isInitialized = !1;
export function initialize(e) {
  return isInitialized
    ? Promise.resolve()
    : new Promise((i) => {
        (eventHandlers = e), (isInitialized = !0), i();
      });
}
export async function loadItems(e) {
  if (!isInitialized)
    throw new Error(
      "CardManager não foi inicializado. Chame initialize() primeiro."
    );
  (items = e),
    await Promise.all(
      subscribers.map((e) => {
        try {
          return Promise.resolve(e(items));
        } catch (e) {
          return (
            console.error("Erro ao notificar subscriber:", e), Promise.resolve()
          );
        }
      })
    );
}
export function getItems() {
  return items;
}
export function filterItems(e) {
  return e
    ? items.filter((i) => {
        const r = e.toLowerCase().trim(),
          s = i.titulo.toLowerCase().includes(r),
          t = "texto" === i.tipo && i.conteudo.toLowerCase().includes(r),
          o = "imagem" === i.tipo && i.descricao?.toLowerCase().includes(r),
          n = i.tags.some((e) => e.toLowerCase().includes(r));
        return s || t || o || n;
      })
    : items;
}

export function subscribe(e) {
  subscribers.push(e);
}
export function unsubscribe(e) {
  subscribers = subscribers.filter((i) => i !== e);
}
function notifySubscribers() {
  subscribers.forEach((e) => e(items));
}
