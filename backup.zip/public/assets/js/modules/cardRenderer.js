import * as shortcodeParser from "./shortcodeParser.js";
import { isNarrator } from "./auth.js";
let appSettings = {};
export function initializeCardRenderer(s) {
  appSettings = s;
}
export function createCardElement(s) {
  const t = document.createElement("div");
  return (
    (t.className = "card"), (t.dataset.id = s.id), renderCardViewMode(t, s), t
  );
}
export function renderCardViewMode(s, t) {
  if (s.querySelector(".card-info-layer")) return void updateCardView(s, t);
  s.classList.remove("editing");
  s.classList.remove("has-overlay-content");
  s.classList.remove("is-description-only");
  s.classList.remove("is-hidden-from-players");
  if (isNarrator() && t && t.isVisibleToPlayers === false) s.classList.add("is-hidden-from-players");

  let e = "";
  if (t && t.url) {
    const i = `padding-bottom: ${t.width && t.height ? (t.height / t.width) * 100 : 75}%`; 
    const a = t.conteudo ? shortcodeParser.parseAllShortcodes(t, appSettings) : {};
    const n = t.descricao ? t.descricao.replace(/\n/g, "<br>") : "";
    let o = "";
    const hasShortcodes = Object.values(a).some((v) => v);
    if (hasShortcodes || n) {
      if (hasShortcodes) s.classList.add("has-overlay-content");
      if (n && !hasShortcodes) s.classList.add("is-description-only");
      o = `\n                <div class="card-info-layer" style="pointer-events: auto;">\n                    <div class="info-content">\n                        <div class="info-group-left">${a.left || ""}</div>\n                        <div class="info-group-right">${a.right || ""}</div>\n                        <div class="info-group-bottom">${a.bottom || ""}</div>\n                        <div class="info-group-details">${a.details || ""}</div>\n                        ${hasShortcodes && n ? '<hr class="tooltip-divider">' : ""}\n                        ${n ? `<div class="tooltip-description">${n}</div>` : ""}\n                    </div>\n                    <div class="info-toggles">\n                        <button class="tooltip-close-btn" aria-label="Fechar"><i class="fas fa-times"></i></button>\n                    </div>\n                </div>`;
    }
    e += `\n            <div class="card-image">\n                <figure class="image" style="${i}">\n                    <img src="${t.url}" alt="${t.titulo}">\n                    ${o}\n                </figure>\n            </div>\n        `;
  }

  e += `<div class="card-content">\n        <p class="title is-4">${t.titulo}</p>`;
  if (t.conteudo) {
    const main = shortcodeParser.parseMainContent(t.conteudo);
    if (main) e += `<div class="content">${main}</div>`;
  }
  if (t.tags && t.tags.length > 0) {
    e += `<div class="tags">${t.tags.map((tag) => `<span class="tag is-info">${tag}</span>`).join(" ")}</div>`;
  }

  e += "</div>";
  s.innerHTML = `\n        <div class="card-actions-top">\n            <button class="action-icon edit-btn"><i class="fas fa-pencil-alt"></i></button>\n            <button class="action-icon delete-btn"><i class="fas fa-trash-alt"></i></button>\n        </div>\n    ` + e;
}
function updateCardView(s, t) {
  s.classList.remove("editing"),
    s.classList.remove("has-overlay-content"),
    s.classList.remove("is-description-only"),
    s.classList.remove("is-hidden-from-players"),
    isNarrator() &&
      !1 === t.isVisibleToPlayers &&
      s.classList.add("is-hidden-from-players");
  const e = s.querySelector(".card-info-layer");
  if (e) {
    const i = t.conteudo
        ? shortcodeParser.parseAllShortcodes(t, appSettings)
        : {},
      a = t.descricao ? t.descricao.replace(/\n/g, "<br>") : "",
      n = Object.values(i).some((s) => s);
    n && s.classList.add("has-overlay-content"),
      a && !n && s.classList.add("is-description-only");
    const o = e.querySelector(".info-content");
    o &&
      (o.innerHTML = `\n                <div class="info-group-left">${
        i.left || ""
      }</div>\n                <div class="info-group-right">${
        i.right || ""
      }</div>\n                <div class="info-group-bottom">${
        i.bottom || ""
      }</div>\n                <div class="info-group-details">\n                    ${
        i.details || ""
      }\n                </div>\n                ${
        n && a ? '<hr class="tooltip-divider">' : ""
      }\n                ${
        a ? `<div class="tooltip-description">${a}</div>` : ""
      }\n            `);
  }
  const i = s.querySelector(".card-content");
  if (i) {
    let s = `<p class="title is-4">${t.titulo}</p>`;
    if (t.conteudo) {
      const e = shortcodeParser.parseMainContent(t.conteudo);
      e && (s += `<div class="content">${e}</div>`);
    }
    t.tags &&
      t.tags.length > 0 &&
      (s += `<div class="tags">${t.tags
        .map((s) => `<span class="tag is-info">${s}</span>`)
        .join(" ")}</div>`),
      (i.innerHTML = s);
  }
}
export function renderCardEditMode(s, t, e) {
  s.classList.add("editing");
  let i = "";
  const a = `padding-bottom: ${
      t.width && t.height ? (t.height / t.width) * 100 : 56.25
    }%;`,
    n = t.url || "";
  (i = `\n        <div class="card-image ${
    n ? "" : "is-placeholder"
  }">\n            <figure class="image" style="${a}">\n                <img src="${n}" alt="${
    t.titulo || ""
  }">\n                <div class="change-image-overlay">\n                    <label class="button is-light">\n                        <span class="icon is-small"><i class="fas fa-camera"></i></span>\n                        <span>${
    n ? "Trocar" : "Adicionar"
  } Imagem</span>\n                        <input type="file" class="edit-image-input" accept="image/*" style="display: none;">\n                    </label>\n                </div>\n            </figure>\n        </div>\n        <div class="card-content">\n            <div class="field"><div class="control"><input class="input edit-titulo" type="text" value="${
    t.titulo || ""
  }" placeholder="Título"></div></div>\n            <div class="field"><div class="control"><textarea class="textarea edit-conteudo" placeholder="Conteúdo...">${
    t.conteudo || ""
  }</textarea></div></div>\n            <div class="field"><div class="control"><textarea class="textarea edit-descricao" placeholder="Descrição (visível ao passar o mouse)">${
    t.descricao || ""
  }</textarea></div></div>\n            <div class="field"><div class="control"><input class="input edit-tags" type="text" value="${
    t.tags?.join(", ") || ""
  }" placeholder="Tags"></div></div>\n            ${
    isNarrator()
      ? `\n                <div class="field">\n                    <label class="checkbox narrator-control">\n                        <input type="checkbox" class="edit-visibility" ${
          !1 !== t.isVisibleToPlayers ? "checked" : ""
        }>\n                        <span class="switch-track"></span>\n                        <span class="switch-label-text">Visível para jogadores</span>\n                    </label>\n                </div>\n                `
      : ""
  }\n            <div class="field" style="margin-top: 1.5em; text-align: right;">\n                <button class="button is-primary save-btn"><span class="icon is-small"><i class="fas fa-save"></i></span> <span>Salvar</span></button>\n            </div>\n        </div>\n    `),
    (s.innerHTML =
      '\n        <div class="card-actions-top">\n            <button class="action-icon save-btn"><i class="fas fa-save"></i></button>\n            <button class="action-icon cancel-btn"><i class="fas fa-times-circle"></i></button>\n        </div>' +
      i);
  const o = s.querySelector(".edit-tags");
  o && e?.onTagInputInit && e.onTagInputInit(o);
  s.querySelectorAll(".save-btn").forEach((i) => {
    i.onclick = (i) => {
      if ((i.preventDefault(), e?.onSave)) {
        const i = s.parentElement;
        e.onSave(s, t, i);
      }
    };
  });
}
export function getCardFormData(s) {
  const t = {
      titulo: s.querySelector(".edit-titulo").value,
      conteudo: s.querySelector(".edit-conteudo").value,
      descricao: s.querySelector(".edit-descricao").value,
      tags: s
        .querySelector(".edit-tags")
        .value.split(",")
        .map((s) => s.trim())
        .filter(Boolean),
    },
    e = s.querySelector(".edit-visibility");
  return e && (t.isVisibleToPlayers = e.checked), t;
}
export function getImageDimensions(s) {
  return new Promise((t, e) => {
    const i = new FileReader();
    (i.onload = (s) => {
      const i = new Image();
      (i.onload = () => t({ width: i.width, height: i.height })),
        (i.onerror = e),
        (i.src = s.target.result);
    }),
      i.readAsDataURL(s);
  });
}
