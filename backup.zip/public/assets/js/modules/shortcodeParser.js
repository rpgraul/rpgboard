export function _parseArguments(t) {
  const e = /"([^"]+)"|\S+/g,
    n = [];
  let s;
  for (; null !== (s = e.exec(t)); ) n.push(s[1] || s[0]);
  return n;
}
export function _parseKeyValueArgs(t) {
  const e = {};
  return (
    t.forEach((t) => {
      const n = t.split("=");
      2 === n.length && (e[n[0].toLowerCase()] = n[1].replace(/^"|"$/g, ""));
    }),
    e
  );
}
function formatNumber(t) {
  return "number" != typeof t && "string" != typeof t
    ? t
    : t.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
}
function _parseStat(t) {
  const e = ["left", "right", "bottom"],
    n = t.filter((t) => !e.includes(t));
  if (0 === n.length) return "";
  const s = (t) => {
    const e = t.match(/(.*?)\s*\((.*?)\)/);
    if (e) {
      const t = e[1].trim();
      return `<span class="has-tooltip" data-tooltip="${e[2].trim()}">${t}</span>`;
    }
    return t || "";
  };
  if (1 === n.length || "null" === n[0].toLowerCase()) {
    return `<div class="shortcode-stat">${s(
      1 === n.length ? n[0] : n.slice(1).join(" ")
    )}</div>`;
  }
  const a = n[n.length - 1];
  return `<div class="shortcode-stat"><strong>${n
    .slice(0, -1)
    .join(" ")}:</strong> ${s(a)}</div>`;
}
function _parseHp(t, e, n) {
  const s = _parseKeyValueArgs(t),
    a = parseInt(s.max, 10) || 100,
    o = void 0 !== s.current ? parseInt(s.current, 10) : a,
    r = Math.max(0, Math.min(o, a));
  return `<div class="shortcode-hp" data-item-id="${e}" data-shortcode="${encodeURIComponent(
    n
  )}" data-max-hp="${a}"><strong class="hp-label">PV</strong><div class="hp-input-wrapper"><input type="number" class="hp-current-input" value="${r}" max="${a}" min="0"><span class="hp-max-value">/ ${a}</span></div></div>`;
}
export function parseHpShortcode(t) {
  if (!t || !t.conteudo) return "";
  const e = t.conteudo.match(/\b[hp]\s+(.*?)[\\]/);
  if (e) {
    return _parseHp(_parseArguments(e[1]), t.id, e[0]);
  }
  return "";
}
function _parseCount(t, e, n) {
  const s = ["left", "right", "bottom"],
    a = t.includes("checkbox"),
    o = t.filter((t) => "checkbox" !== t && !s.includes(t)),
    r = _parseKeyValueArgs(o.filter((t) => t.includes("=")));
  let i = "number";
  r.icon ? (i = "custom-icon") : r.theme ? (i = r.theme) : a && (i = "default");
  const c = o.find((t) => !t.includes("=")) || "",
    l = parseInt(r.max, 10) || 0;
  let u = void 0 !== r.current ? parseInt(r.current, 10) : l;
  if (((u = Math.max(0, Math.min(u, l))), !c && 0 === l)) return "";
  const d = `data-item-id="${e}" data-shortcode="${encodeURIComponent(n)}"`;
  let p = "";
  if (["default", "arrow", "potion", "custom-icon"].includes(i) && l > 0) {
    p = `<span class="count-checkboxes-interactive theme-${i}">`;
    for (let t = 1; t <= l; t++) {
      const e = t <= u;
      let n = "";
      if ("arrow" === i) n = '<i class="fas fa-arrow-up"></i>';
      else if ("potion" === i) n = '<i class="fas fa-flask"></i>';
      else if ("custom-icon" === i) {
        n = `<i class="fas fa-${r.icon.replace(/["']/g, "")}"></i>`;
      }
      p += `<span class="count-checkbox ${
        e ? "is-checked" : ""
      }" data-value="${t}" role="button" tabindex="0">${n}</span>`;
    }
    p += "</span>";
  } else
    p =
      `\n<span class="count-value-interactive">\n<button class="count-btn" data-action="decrement" aria-label="Diminuir">-</button>\n<span class="count-current-value">${u}</span>\n<span class="count-separator">/</span>\n<span class="count-max-value">${l}</span>\n<button class="count-btn" data-action="increment" aria-label="Aumentar">+</button>\n</span>\n`
        .trim()
        .replace(/\s+/g, " ");
  return (
    (p = `<div class="count-representation">${p}</div>`),
    `<div class="shortcode-count is-interactive" ${d}>${
      c ? `<strong class="count-name">${c}:</strong> ` : ""
    }${p}</div>`
  );
}
export function parseMainContent(t) {
  if (!t) return "";
  let e = t;
  return (
    (e = e.replace(/<p>\s*(\[nota\s+[^\]]+\])\s*<\/p>/gi, "$1")),
    (e = e.replace(/<p>\s*(\[\/nota\])\s*<\/p>/gi, "$1")),
    (e = e.replace(
      /\[nota\s+titulo="([^"]+)"\s*(#)?\]([\s\S]*?)\[\/nota\]/gi,
      (t, e, n, s) =>
        `\n            <div class="shortcode-nota ${
          n ? "is-hidden-from-players" : ""
        }">\n                <div class="nota-header" role="button" tabindex="0">\n                    <span class="nota-title">${e}</span>\n                    <span class="nota-icon"><i class="fas fa-plus"></i></span>\n                </div>\n                <div class="nota-content">\n                    ${s.trim()}\n                </div>\n            </div>\n        `
    )),
    (e = e.replace(/\[(hide|#)\]([\s\S]*?)\[\/(hide|#)\]/gi, (t, e, n, s) =>
      e.toLowerCase() !== s.toLowerCase()
        ? t
        : `<div class="is-hidden-from-players">${n}</div>`
    )),
    (e = e.replace(/\[(\*?)(stat|hp|count|money)\s.*?\]/gi, "")),
    (e = e.replace(/<p>\s*<\/p>/gi, "")),
    e.trim()
  );
}
export function parseAllShortcodes(t, e = {}) {
  if (!t || !t.conteudo)
    return { left: "", right: "", bottom: "", details: "" };
  const n = { left: [], right: [], bottom: [], details: [] },
    s = { stat: 1, money: 2, hp: 3, count: 4, default: 99 },
    a = t.conteudo,
    o = /\[(.*?)\]/g;
  let r;
  const i = [];
  for (; null !== (r = o.exec(a)); )
    i.push({ full: r[0], inner: r[1], index: r.index });
  const c = [],
    l = /\[(hide|#)\]([\s\S]*?)\[\/(hide|#)\]/gi;
  let u;
  for (; null !== (u = l.exec(a)); ) {
    const [t, e, n, s] = u;
    if (e.toLowerCase() === s.toLowerCase()) {
      const e = u.index + t.indexOf(n);
      c.push({ start: e, end: e + n.length });
    }
  }
  const d = i
    .map((t) => {
      const e = _parseArguments(t.inner),
        n = e[0] || "",
        a = n.replace(/^[#*]+/, "").toLowerCase();
      if (!["stat", "hp", "count", "money"].includes(a)) return null;
      const o = n.startsWith("#"),
        r = e.includes("#"),
        i = ((l = t.index), c.some((t) => l >= t.start && l < t.end));
      var l;
      let u = e.slice(1);
      return (
        r && (u = u.filter((t) => "#" !== t)),
        {
          command: a,
          args: u,
          originalShortcode: t.full,
          isHidden: o || r || i,
          order: s[a] || s.default,
        }
      );
    })
    .filter(Boolean);
  d.sort((t, e) => t.order - e.order);
  const p = (t, e) =>
    e ? `<div class="is-hidden-from-players">${t}</div>` : t;
  return (
    d.forEach((s) => {
      let a = null;
      s.args.includes("left")
        ? (a = "left")
        : s.args.includes("right")
        ? (a = "right")
        : s.args.includes("bottom") && (a = "bottom");
      let o = "";
      switch (s.command) {
        case "stat":
          (o = _parseStat(s.args)), n[a || "left"].push(p(o, s.isHidden));
          break;
        case "hp":
          (o = _parseHp(s.args, t.id, s.originalShortcode)),
            n[a || "bottom"].push(p(o, s.isHidden));
          break;
        case "money":
          const r = _parseKeyValueArgs(s.args),
            i = parseFloat(r.current) || 0;
          let c = r.currency || "";
          if (!c) {
            const t = ["left", "right", "bottom"],
              n = s.args.find((e) => !e.includes("=") && !t.includes(e));
            n ? (c = n) : e.defaultCurrency && (c = e.defaultCurrency);
          }
          const l = formatNumber(i);
          (o = `\n<div class="shortcode-money is-interactive" data-item-id="${
            t.id
          }" data-shortcode="${encodeURIComponent(
            s.originalShortcode
          )}">\n<i class="fas fa-coins"></i>\n<span class="money-value-display">${l}</span><input type="text" class="money-value-input is-hidden" value="${i}"><span class="money-currency">${c}</span>\n</div>\n`
            .trim()
            .replace(/\s+/g, " ")),
            n[a || "left"].push(p(o, s.isHidden));
          break;
        case "count":
          const u = s.originalShortcode.includes("[*count"),
            d = _parseCount(s.args, t.id, s.originalShortcode),
            h = p(d, s.isHidden);
          u ? n[a || "right"].push(h) : a ? n[a].push(h) : n.details.push(h);
      }
    }),
    {
      left: n.left.join(""),
      right: n.right.join(""),
      bottom: n.bottom.join(""),
      details: n.details.join(""),
    }
  );
}
export function extractRawShortcodes(t) {
  if (!t) return [];
  const e = /\[(.*?)\]/g,
    n = [];
  let s;
  for (; null !== (s = e.exec(t)); ) n.push(s[0]);
  return n;
}
