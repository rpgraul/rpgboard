export function rollDice(e) {
  return Math.floor(Math.random() * e) + 1;
}
export function showDiceResult(e, t) {
  const o = document.createElement("div");
  (o.className = "notification is-info dice-notification"),
    (o.style.position = "fixed"),
    (o.style.bottom = "20px"),
    (o.style.right = "20px"),
    (o.style.zIndex = "9999"),
    (o.innerHTML = `\n        <button class="delete" type="button"></button>\n        <p><strong>${
      t || "Alguém"
    }</strong> rolou:</p>\n        <div class="dice-result">${e}</div>\n    `),
    document.body.appendChild(o);
  o.querySelector(".delete").addEventListener("click", () => {
    o.remove();
  }),
    setTimeout(() => {
      document.body.contains(o) && o.remove();
    }, 5e3);
}
